<?php
/**
 * Advanced Search - Search Box
 *
 * @package Astra Addon
 */

?>
<div class="ast-search-menu-icon search-box ast-inline-search">
	<?php astra_addon_get_search_form(); ?>
</div>
