<?php

$block_slug = 'uagb/slider-pro';

$block_data = array(
	'dynamic_assets' => array(
		'dir'        => 'slider-pro',
		'plugin-dir' => SPECTRA_PRO_DIR . '/',
	),
);
