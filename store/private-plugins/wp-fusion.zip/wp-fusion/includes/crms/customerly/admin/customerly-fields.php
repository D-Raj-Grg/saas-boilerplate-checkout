<?php

$customerly_fields = array();

$customerly_fields['first_name'] = array(
	'crm_label' => 'Name',
	'crm_field' => 'name'
);

$customerly_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email'
);

$customerly_fields['user_id'] = array(
	'crm_label' => 'User ID',
	'crm_field' => 'user_id'
);