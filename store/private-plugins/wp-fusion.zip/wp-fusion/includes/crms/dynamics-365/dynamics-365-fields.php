<?php

$dynamics_fields = array();

$dynamics_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'firstname',
);

$dynamics_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'lastname',
);

$dynamics_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'emailaddress1',
);
