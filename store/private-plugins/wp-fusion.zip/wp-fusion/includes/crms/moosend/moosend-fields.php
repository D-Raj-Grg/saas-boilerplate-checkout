<?php

$moosend_fields = array();


$moosend_fields['display_name'] = array(
	'crm_label' => 'Name',
	'crm_field' => 'name',
);

$moosend_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'firstname',
);

$moosend_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'lastname',
);

$moosend_fields[] = array(
	'crm_label' => 'Name',
	'crm_field' => 'name',
);

$moosend_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email',
);

$moosend_fields['phone_number'] = array(
	'crm_label' => 'Mobile',
	'crm_field' => 'mobile',
);
