<?php

$maropost_fields = array();

$maropost_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'first_name'
);

$maropost_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'last_name'
);

$maropost_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email'
);

$maropost_fields['phone_number'] = array(
	'crm_label' => 'Phone',
	'crm_field' => 'phone_number'
);

$maropost_fields['billing_city'] = array(
	'crm_label' => 'City',
	'crm_field' => 'city'
);

$maropost_fields['website'] = array(
	'crm_label' => 'Website',
	'crm_field' => 'website'
);

$maropost_fields['billing_country'] = array(
	'crm_label' => 'Country',
	'crm_field' => 'country'
);

