<?php

$bento_fields = array();

$bento_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'first_name',
);

$bento_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'last_name',
);

$bento_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email',
);

$bento_fields['phone_number'] = array(
	'crm_label' => 'Phone',
	'crm_field' => 'phone',
);
