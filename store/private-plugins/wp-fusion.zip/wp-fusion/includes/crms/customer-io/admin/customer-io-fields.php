<?php

$customer_io_fields = array();

$customer_io_fields['user_email'] = array(
	'crm_label' => 'Email Address',
	'crm_field' => 'email',
);

$customer_io_fields['user_registered'] = array(
	'crm_label' => 'Created At',
	'crm_field' => 'created_at',
);
