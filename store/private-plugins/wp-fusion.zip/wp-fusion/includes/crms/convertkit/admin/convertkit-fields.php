<?php

$convertkit_fields = array();

$convertkit_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'first_name'
);

$convertkit_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email_address'
);