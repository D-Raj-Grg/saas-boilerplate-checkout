<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


class WPF_Memberoni extends WPF_Integrations_Base {

	/**
	 * The slug for WP Fusion's module tracking.
	 *
	 * @since 3.38.14
	 * @var string $slug
	 */

	public $slug = 'memberoni';

	/**
	 * The plugin name for WP Fusion's module tracking.
	 *
	 * @since 3.38.14
	 * @var string $name
	 */
	public $name = 'Memberoni';

	/**
	 * The link to the documentation on the WP Fusion website.
	 *
	 * @since 3.38.14
	 * @var string $docs_url
	 */
	public $docs_url = 'https://wpfusion.com/documentation/learning-management/memberoni/';


	/**
	 * Gets things started
	 *
	 * @access  public
	 * @since   3.26.1
	 * @return  void
	 */

	public function init() {

		add_action( 'memberoni_after_mark_complete', array( $this, 'mark_course_complete' ) );
		add_action( 'memberoni_after_track_lesson', array( $this, 'mark_lesson_complete' ) );
		add_action( 'memberoni_after_roadmap_step', array( $this, 'mark_roadmap_step_complete' ) );
		add_action( 'memberoni_after_roadmap_complete', array( $this, 'mark_roadmap_complete' ) );

		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ), 20, 2 );
		add_action( 'save_post', array( $this, 'save_meta_box_data' ) );

	}


	/**
	 * Apply tags when course marked complete
	 *
	 * @access public
	 * @return void
	 */

	public function mark_course_complete() {

		$post_id = get_the_ID();

		$settings = get_post_meta( $post_id, 'wpf_settings_memberoni', true );

		if ( ! empty( $settings ) && ! empty( $settings['apply_tags_complete'] ) ) {

			wp_fusion()->user->apply_tags( $settings['apply_tags_complete'] );

		}

	}

	/**
	 * Apply tags when lesson marked complete
	 *
	 * @access public
	 * @return void
	 */

	public function mark_lesson_complete() {

		if ( ! isset( $_POST['lesson_id'] ) ) {
			return;
		}

		$post_id = intval( $_POST['lesson_id'] );

		$settings = get_post_meta( $post_id, 'wpf_settings_memberoni', true );

		if ( ! empty( $settings ) && ! empty( $settings['apply_tags_complete'] ) ) {

			wp_fusion()->user->apply_tags( $settings['apply_tags_complete'] );

		}

	}

	/**
	 * Apply tags when roadmap step marked complete
	 *
	 * @since 3.45.0
	 * 
	 * @param int $post_id The ID of the post.
	 */
	public function mark_roadmap_step_complete( $post_id ) {

		if ( isset( $_GET['t'] ) ) {
			$post_id = intval( $_GET['t'] );
		}

		$settings = get_post_meta( $post_id, 'wpf_settings_memberoni', true );

		if ( ! empty( $settings ) && ! empty( $settings['apply_tags_complete'] ) ) {
			wp_fusion()->user->apply_tags( $settings['apply_tags_complete'] );
		}

	}

	/**
	 * Apply tags when entire roadmap marked complete
	 *
	 * @since 3.45.0	
	 * 
	 * @param int $post_id The ID of the post.
	 */

	public function mark_roadmap_complete( $post_id ) {

		$settings = get_post_meta( $post_id, 'wpf_settings_memberoni', true );

		if ( ! empty( $settings ) && ! empty( $settings['apply_tags_complete'] ) ) {
			wp_fusion()->user->apply_tags( $settings['apply_tags_complete'] );
		}

	}


	/**
	 * Adds meta box
	 *
	 * @access public
	 * @return void
	 */

	public function add_meta_box( $post_id, $data ) {

		add_meta_box( 'wpf-memberoni-meta', 'WP Fusion Settings', array( $this, 'meta_box_callback' ), array( 'memberoni_course', 'memberoni_roadmap' ) );

	}


	/**
	 * Displays meta box content
	 *
	 * @access public
	 * @return mixed
	 */

	public function meta_box_callback( $post ) {

		$settings = array(
			'apply_tags_complete' => array(),
		);

		if ( get_post_meta( $post->ID, 'wpf_settings_memberoni', true ) ) {
			$settings = array_merge( $settings, get_post_meta( $post->ID, 'wpf_settings_memberoni', true ) );
		}

		echo '<table class="form-table"><tbody>';

		echo '<tr>';

		echo '<th scope="row"><label for="tag_link">' . __( 'Apply tags when completed:', 'wp-fusion' ) . '</label></th>';
		echo '<td>';

		$args = array(
			'setting'   => $settings['apply_tags_complete'],
			'meta_name' => 'wpf_settings_memberoni',
			'field_id'  => 'apply_tags_complete',
		);

		wpf_render_tag_multiselect( $args );

		$post_type = get_post_type( $post );
		$content_type = 'course';

		if ( $post_type === 'memberoni_roadmap' ) {
			$content_type = get_post_meta( $post->ID, 'roadmap_page_type', true ) === 'step' ? 'roadmap step' : 'roadmap';
		} elseif ( get_post_meta( $post->ID, 'course_page_type', true ) === 'lesson' ) {
			$content_type = 'lesson';
		}

		echo '<span class="description">' . sprintf( __( 'The selected tags will be applied in %1$s when this %2$s is marked complete.', 'wp-fusion' ), wp_fusion()->crm->name, $content_type ) . '</span>';
		echo '</td>';

		echo '</tr>';

		echo '</tbody></table>';

	}

	/**
	 * Runs when WPF meta box is saved
	 *
	 * @access public
	 * @return void
	 */

	public function save_meta_box_data( $post_id ) {

		if ( ! empty( $_POST['wpf_settings_memberoni'] ) ) {
			update_post_meta( $post_id, 'wpf_settings_memberoni', $_POST['wpf_settings_memberoni'] );
		} else {
			delete_post_meta( $post_id, 'wpf_settings_memberoni' );
		}

	}


}

new WPF_Memberoni();
