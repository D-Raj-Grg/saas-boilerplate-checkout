import WpfSelect from '@verygoodplugins/wpfselect';
import { BaseControl } from '@wordpress/components';

export default function AmountTagSelector( { level, updateLevelTags } ) {
	return (
		<BaseControl
			id={ `wpf-tag-select-${ level.id }` }
			label={ level.label }
		>
			<WpfSelect
				id={ `wpf-tag-select-${ level.id }` }
				existingTags={ level.tags }
				onChange={ ( value ) => {
					updateLevelTags( level.id, value );
				} }
			/>
		</BaseControl>
	);
}
