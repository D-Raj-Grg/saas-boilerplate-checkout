<?php
/**
 * Pro templates - class to add the pro templates in the template screen.
 *
 * @package sureforms-pro.
 * @since 0.0.1
 */

namespace SRFM_Pro\Templates;

use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class to add the pro templates in the template screen.
 *
 * @since 0.0.1
 */
class Pro_Templates {
	use Get_Instance;

	/**
	 * Pro Block patterns to register.
	 *
	 * @var array<string>
	 * @since 0.0.1
	 */
	protected $pro_patterns = [];

	/**
	 * Class constructor.
	 *
	 * @since 0.0.1
	 * @return void
	 */
	public function __construct() {
		$this->pro_patterns = [
			'job-application-form',
		];

		add_filter( 'srfm_block_patterns', [ $this, 'add_pro_block_patterns' ], 10, 1 );
	}

	/**
	 * Add pro block pattern to the free block patterns array
	 *
	 * @hooked srfm_block_patterns
	 * @param array<string> $patterns Block patterns.
	 * @since 0.0.1
	 * @return array<string> Block patterns.
	 */
	public function add_pro_block_patterns( $patterns ) {
		// merging the pro patterns with the free patterns.
		return array_merge( $patterns, $this->pro_patterns );
	}

}
