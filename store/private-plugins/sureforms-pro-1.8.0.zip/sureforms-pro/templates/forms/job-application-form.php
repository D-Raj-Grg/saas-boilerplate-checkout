<?php
/**
 * Job Application Form pattern.
 *
 * @link       https://sureforms.com
 * @since      0.0.1
 * @package    SureForms_Pro/Templates/Forms
 * @author     SureForms <https://sureforms.com/>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

return [
	'title'            => __( 'Job Application Form', 'sureforms-pro' ),
	'slug'             => 'job-application-form',
	'info'             => __( 'Creates a Job Application Form', 'sureforms-pro' ),
	'categories'       => [ 'sureforms_form' ],
	'templateCategory' => __( 'Job Application', 'sureforms-pro' ),
	'postTypes'        => SRFM_FORMS_POST_TYPE,
	'content'          => '<!-- wp:srfm/advanced-heading {"block_id":"88614146","headingTitle":"Job Application Form","headingDescToggle":true,"headingDesc":"We usually respond within 24 hours but it can take longer on weekends and around public holidays.","headSpace":16,"subHeadSpace":24,"subHeadFontWeight":"400","subHeadFontSize":18,"formId":785} /--><!-- wp:srfm/input {"block_id":"e8a489f7","required":true,"label":"Name","formId":785,"slug":"name"} /--><!-- wp:srfm/email {"block_id":"a5728450","required":true,"formId":785,"slug":"srfm-email"} /--><!-- wp:srfm/input {"block_id":"9ec2463e","required":true,"label":"Role for you are Applying","formId":785,"slug":"subject"} /--><!-- wp:srfm/textarea {"block_id":"4afb9556","required":false,"label":"Cover Letter","formId":785,"slug":"message"} /--><!-- wp:srfm/upload {"block_id":"53261690","required":true,"label":"Resume","allowedFormats":[{"value":"pdf","label":"pdf"},{"value":"docx","label":"docx"}],"formId":785} /-->',
	'isPro'            => true,
];
