<?php
/**
 * Sureforms Submit Class file.
 *
 * @package sureforms-pro.
 * @since 0.0.1
 */

namespace SRFM_Pro\Inc;

use SRFM\Inc\Helper as SRFM_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Helper Helper Class.
 *
 * @since 0.0.1
 */
class Helper {
	use Get_Instance;

	/**
	 * Sureforms SVGs.
	 *
	 * @var mixed srfm_svgs
	 */
	private static $srfm_pro_svgs = null;

	/**
	 * Get an SVG Icon
	 *
	 * @since 0.0.1
	 * @param string $icon the icon name.
	 * @param string $class if the baseline class should be added.
	 * @param string $html Custom attributes inside svg wrapper.
	 * @param string $wrapper_tag SVG icon wrapper html tag type. Default is span.
	 * @return string
	 */
	public static function fetch_pro_svg( $icon = '', $class = '', $html = '', $wrapper_tag = 'span' ) {

		$output = sprintf(
			'<%1$s class="%2$s" %3$s>',
			esc_attr( $wrapper_tag ),
			! empty( $class ) ? esc_attr( "srfm-icon {$class}" ) : 'srfm-icon',
			$html
		);

		if ( ! self::$srfm_pro_svgs ) {
			ob_start();

			include_once SRFM_PRO_DIR . 'assets/svg/svgs.json'; // phpcs:ignore WordPressVIPMinimum.Files.IncludingNonPHPFile.IncludingNonPHPFile -- Required to get svg.json.
			// phpcs:ignore /** @phpstan-ignore-next-line */
			self::$srfm_pro_svgs = json_decode( ob_get_clean(), true );
			self::$srfm_pro_svgs = apply_filters( 'srfm_pro_svg_icons', self::$srfm_pro_svgs );
		}

			$output .= self::$srfm_pro_svgs[ $icon ] ?? '';
			$output .= "</{$wrapper_tag}>";

			return $output;
	}

	/**
	 * Get an SVG Icon
	 *
	 * @since 0.0.1
	 * @param string $icon the icon name.
	 * @return string
	 */
	public static function get_pro_icon( $icon = '' ) {
		if ( ! self::$srfm_pro_svgs ) {
			$file_path = SRFM_PRO_DIR . 'assets/svg/svgs.json';

			if ( file_exists( $file_path ) ) {
				$file_contents = file_get_contents( $file_path ); //phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

				if ( ! empty( $file_contents ) ) {
					self::$srfm_pro_svgs = json_decode( $file_contents, true );
					self::$srfm_pro_svgs = apply_filters( 'srfm_pro_svg_icons', self::$srfm_pro_svgs );
				}
			}
		}

		return self::$srfm_pro_svgs[ $icon ] ?? '';
	}

	/**
	 * Print sanitized SVG Icon.
	 *
	 * @since 1.4.1
	 * @param string $icon the icon name.
	 * @return void
	 */
	public static function print_pro_icon( $icon = '' ) {
		$allowed_svg_attrs = [
			'svg'      => [
				'width'   => true,
				'height'  => true,
				'fill'    => true,
				'viewbox' => true,
				'xmlns'   => true,
			],
			'g'        => [
				'clip-path' => true,
			],
			'defs'     => [],
			'clipPath' => [
				'id' => true,
			],
			'path'     => [
				'd'               => true,
				'opacity'         => true,
				'class'           => true,
				'stroke'          => true,
				'stroke-width'    => true,
				'stroke-linecap'  => true,
				'stroke-linejoin' => true,
			],
			'rect'     => [
				'width'  => true,
				'height' => true,
				'fill'   => true,
			],
		];

		echo wp_kses( self::get_pro_icon( $icon ), $allowed_svg_attrs );
	}

	/**
	 * Registers script translations for a specific handle.
	 *
	 * This function sets the script translations for a given script handle, allowing
	 * localization of JavaScript strings using the specified text domain and path.
	 *
	 * @param string $handle The script handle to apply translations to.
	 * @param string $domain Optional. The text domain for translations. Default is 'sureforms'.
	 * @param string $path   Optional. The path to the translation files. Default is the 'languages' folder in the SureForms directory.
	 *
	 * @since 1.0.5
	 * @return void
	 */
	public static function register_script_translations( $handle, $domain = 'sureforms-pro', $path = SRFM_PRO_DIR . 'languages' ) {
		wp_set_script_translations( $handle, $domain, $path );
	}

	/**
	 * Return the string with hsl color for the given hex color.
	 *
	 * @param string    $hex_color The hex color.
	 * @param int|float $alpha The alpha value.
	 *
	 * @since 1.6.3
	 * @return string The hsl color string.
	 */
	public static function get_hsl_notation_from_hex( $hex_color, $alpha = 1 ) {
		return 'hsl( from ' . $hex_color . ' h s l / ' . $alpha . ')';
	}

	/**
	 * Return the classes based on normal and hover state to add to the submit button.
	 *
	 * @param string $background_type The background type of the button's normal state.
	 * @param string $hover_type The backround type of the button's hover state. Default 'normal'.
	 *
	 * @since 1.6.3
	 * @return string The classes to add to the button.
	 */
	public static function get_button_background_classes( $background_type, $hover_type ) {
		$background_type_class = $background_type ? 'srfm-btn-bg-' . $background_type : '';
		$hover_type_class      = $hover_type ? 'srfm-btn-bg-hover-' . $hover_type : '';

		return SRFM_Helper::join_strings( [ $background_type_class, $hover_type_class ] );
	}

	/**
	 * Add CSS variables to the form.
	 *
	 * @param array $css_variables The CSS variables to add.
	 * @since 1.6.3
	 * @return void
	 */
	public static function add_css_variables( $css_variables ) {
		if ( empty( $css_variables ) || ! is_array( $css_variables ) ) {
			return;
		}
		foreach ( $css_variables as $key => $value ) {
			if ( ! empty( $value ) ) {
				echo esc_html( SRFM_Helper::get_string_value( $key ) ) . ': ' . esc_html( SRFM_Helper::get_string_value( $value ) ) . ';';
			}
		}
	}

	/**
	 * Get the WordPress file types.
	 *
	 * @since 1.8.0
	 * @return array<string,mixed> An associative array representing the file types.
	 */
	public static function get_wp_file_types() {
		$formats = [];
		$mimes   = get_allowed_mime_types();
		$maxsize = wp_max_upload_size() / 1048576;
		if ( ! empty( $mimes ) ) {
			foreach ( $mimes as $type => $mime ) {
				$multiple = explode( '|', $type );
				foreach ( $multiple as $single ) {
					$formats[] = $single;
				}
			}
		}

		return [
			'formats' => $formats,
			'maxsize' => $maxsize,
		];
	}

	/**
	 * Summary of delete_upload_file_from_subdir
	 *
	 * @param string $file_url The file URL to delete.
	 * @param string $subdir The subdirectory to delete the file from.
	 *
	 * @since 1.8.0
	 * @return bool
	 */
	public static function delete_upload_file_from_subdir( $file_url, $subdir = 'sureforms/' ) {
		// Decode the file URL.
		$file_url = urldecode( $file_url );

		// Check if the file URL is empty.
		if ( empty( $file_url ) || ! is_string( $file_url ) ) {
			return false;
		}

		// Normalize and sanitize the subdirectory.
		$subdir = trailingslashit( sanitize_text_field( $subdir ) );

		// Get the base upload directory.
		$upload_dir       = wp_upload_dir();
		$base_upload_path = trailingslashit( $upload_dir['basedir'] ) . $subdir;

		// Extract only the filename from URL.
		$filename = basename( $file_url );

		// Get the file extension.
		$file_extension = pathinfo( $filename, PATHINFO_EXTENSION );

		// Validate the file extension.
		if ( empty( $file_extension ) || ! is_string( $file_extension ) ) {
			return false;
		}

		// Get file format.
		$file_format     = self::get_wp_file_types();
		$file_extensions = isset( $file_format['formats'] ) && is_array( $file_format['formats'] ) ? $file_format['formats'] : [];

		// Check if the file extension is allowed.
		if ( ! in_array( $file_extension, $file_extensions, true ) ) {
			return false;
		}

		// Construct the full file path.
		$file_path = $base_upload_path . $filename;

		// Resolve real paths.
		$real_file_path = realpath( $file_path );
		$real_base_path = realpath( $base_upload_path );

		// Security check: ensure file is inside the target subdir.
		if ( ! $real_file_path || ! $real_base_path || strpos( $real_file_path, $real_base_path ) !== 0 ) {
			return false;
		}

		// Delete if file exists.
		if ( file_exists( $real_file_path ) ) {
			return unlink( $real_file_path );
		}

		return false;
	}
}
